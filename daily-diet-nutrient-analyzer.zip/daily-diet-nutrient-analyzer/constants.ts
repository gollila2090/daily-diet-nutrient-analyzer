
export const GEMINI_MODEL_TEXT = "gemini-2.5-flash-preview-04-17";
export const GEMINI_MODEL_VISION = "gemini-2.5-flash-preview-04-17"; // Gemini 1.5 Flash supports multimodal input

export const MEAL_TYPES = ["아침", "점심", "저녁", "간식"];
