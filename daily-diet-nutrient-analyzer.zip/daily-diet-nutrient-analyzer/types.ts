export enum MealType {
  Breakfast = "아침",
  Lunch = "점심",
  Dinner = "저녁",
  Snack = "간식",
}

export enum Gender {
  Male = "male",
  Female = "female",
}

export interface UserProfile {
  gender: Gender | '';
  age: number | ''; 
  height: number | ''; // cm
  weight: number | ''; // kg
  targetWeight?: number | ''; // kg, optional
  aspirations?: string; // optional
}

export interface NutrientInfo {
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
}

export interface AnalyzedFoodItem extends NutrientInfo {
  name: string;
}

export interface AnalysisResult {
  items: AnalyzedFoodItem[];
  totalNutrients: NutrientInfo;
}

export interface ExerciseRecommendation {
  name: string;
  duration: string;
  estimatedCaloriesBurned: string; 
}

export interface UserTargets extends NutrientInfo {}

export interface StoredMealRecord {
  id: string; // Unique ID for each meal record
  date: string; // YYYY-MM-DD format
  mealType: MealType | '';
  foodNameHint?: string;
  analysis: AnalysisResult; 
}