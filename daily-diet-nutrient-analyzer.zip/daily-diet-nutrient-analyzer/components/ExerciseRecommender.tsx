
import React from 'react';
import { ExerciseRecommendation } from '../types';

interface ExerciseRecommenderProps {
  recommendation: ExerciseRecommendation | null; // Changed from recommendations: ExerciseRecommendation[]
}

const DumbbellIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
 <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M14.4 14.4 9.6 9.6"></path>
    <path d="M18.657 5.343a2.828 2.828 0 1 1-4 4L12 12l-2.657-2.657a2.828 2.828 0 1 1-4-4 2.828 2.828 0 0 1 4 0L12 12l2.657 2.657a2.828 2.828 0 1 1 4 4L12 12l2.657-2.657a2.828 2.828 0 0 1 0-4Z"></path>
    <path d="m21 21-1.5-1.5"></path><path d="m3 3 1.5 1.5"></path>
  </svg>
);

const YoutubeIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17"></path>
    <path d="m10 15 5-3-5-3z"></path>
  </svg>
);


export const ExerciseRecommender: React.FC<ExerciseRecommenderProps> = ({ recommendation }) => {
  if (!recommendation) { // If no single recommendation, return null
    return null;
  }

  return (
    <div className="mt-6 p-6 bg-white shadow-lg rounded-lg border border-gray-200">
      <h2 className="text-2xl font-semibold text-gray-800 mb-6 flex items-center">
        <DumbbellIcon className="w-7 h-7 mr-2 text-green-600" />
        운동 추천
      </h2>
      <div className="p-4 bg-green-50 rounded-md shadow-sm border border-green-200">
        <h3 className="font-semibold text-lg text-green-700">{recommendation.name}</h3>
        <p className="text-sm text-gray-600">
          <span className="font-medium">권장 시간:</span> {recommendation.duration}
        </p>
        <p className="text-sm text-gray-600">
          <span className="font-medium">예상 소모 칼로리:</span> {recommendation.estimatedCaloriesBurned}
        </p>
        <a
          href={`https://www.youtube.com/results?search_query=${encodeURIComponent(recommendation.name + " 운동")}`}
          target="_blank"
          rel="noopener noreferrer"
          className="mt-2 inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded-md shadow-sm text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
        >
          <YoutubeIcon className="mr-1.5 h-4 w-4" />
          YouTube에서 검색
        </a>
      </div>
    </div>
  );
};
