
import React from 'react';

// Simple Salad Bowl icon as an SVG component
const SaladBowlIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    width="32" 
    height="32" 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round" 
    className={props.className}
  >
    <path d="M5.9 21.004C4.167 20.36 3 18.82 3 17A4.002 4.002 0 0 1 5.093 13.5H18.907A4.002 4.002 0 0 1 21 17c0 1.82-.167 3.36-1.9 4.004"/>
    <path d="m5 13.5 1.5-4.5h11L19 13.5"/>
    <path d="M12 13.5V9"/>
    <path d="M12 3s-2 2-4 2"/>
    <path d="M12 3s2 2 4 2"/>
  </svg>
);


export const Header: React.FC = () => {
  return (
    <header className="w-full gradient-header text-white p-4 md:p-6 shadow-lg rounded-t-lg max-w-2xl">
      <div className="w-full flex justify-center items-center space-x-3">
        <SaladBowlIcon className="w-8 h-8 text-white" />
        <h1 className="text-2xl md:text-3xl font-bold">건강한 식단 관리</h1>
      </div>
    </header>
  );
};
