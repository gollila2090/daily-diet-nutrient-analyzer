
import React from 'react';
import { AnalysisResult } from '../types';

interface AnalysisDisplayProps {
  result: AnalysisResult;
  healthAdvice?: string[];
}

const PieChartIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21.21 15.89A10 10 0 1 1 8 2.83"></path>
    <path d="M22 12A10 10 0 0 0 12 2v10z"></path>
  </svg>
);

const InformationCircleIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="24" height="24">
    <path fillRule="evenodd" d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12Zm8.706-1.442c0-.726.586-1.312 1.312-1.312s1.312.586 1.312 1.312v1.226c0 .726-.586 1.312-1.312 1.312s-1.312-.586-1.312-1.312V10.558Zm-1.87 4.542a.75.75 0 0 1 .75-.75h2.25a.75.75 0 0 1 0 1.5H10.5a.75.75 0 0 1-.75-.75Z" clipRule="evenodd" />
  </svg>
);

export const AnalysisDisplay: React.FC<AnalysisDisplayProps> = ({ result, healthAdvice }) => {
  const { items, totalNutrients } = result;

  return (
    <div className="mt-6 p-6 bg-white shadow-lg rounded-lg border border-gray-200">
      <h2 className="text-2xl font-semibold text-gray-800 mb-6 flex items-center">
        <PieChartIcon className="w-7 h-7 mr-2 text-purple-600" />
        음식 분석 결과
      </h2>

      {items.length > 0 && (
        <div className="mb-6">
          <h3 className="text-lg font-medium text-gray-700 mb-3">인식된 음식 항목:</h3>
          <ul className="space-y-3">
            {items.map((item, index) => (
              <li key={index} className="p-4 bg-gray-50 rounded-md shadow-sm border border-gray-200">
                <p className="font-semibold text-indigo-700">{item.name}</p>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-sm text-gray-600 mt-1">
                  <span>칼로리: {Number(item.calories).toFixed(1)} kcal</span>
                  <span>단백질: {Number(item.protein).toFixed(1)} g</span>
                  <span>탄수화물: {Number(item.carbs).toFixed(1)} g</span>
                  <span>지방: {Number(item.fat).toFixed(1)} g</span>
                </div>
              </li>
            ))}
          </ul>
        </div>
      )}

      <div>
        <h3 className="text-lg font-medium text-gray-700 mb-3">총 영양 정보:</h3>
        <div className="p-4 bg-indigo-50 rounded-md shadow-sm border border-indigo-200">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-3">
            <p className="text-lg font-semibold text-indigo-800">
              총 칼로리: <span className="font-bold">{Number(totalNutrients.calories).toFixed(1)} kcal</span>
            </p>
            <p className="text-gray-700">총 단백질: {Number(totalNutrients.protein).toFixed(1)} g</p>
            <p className="text-gray-700">총 탄수화물: {Number(totalNutrients.carbs).toFixed(1)} g</p>
            <p className="text-gray-700">총 지방: {Number(totalNutrients.fat).toFixed(1)} g</p>
          </div>
        </div>
      </div>

      {healthAdvice && healthAdvice.length > 0 && (
        <div className="mt-6 pt-6 border-t border-gray-200">
          <h3 className="text-lg font-medium text-gray-700 mb-3 flex items-center">
            <InformationCircleIcon className="w-6 h-6 mr-2 text-blue-500" />
            오늘의 식단 조언
          </h3>
          <ul className="space-y-2">
            {healthAdvice.map((advice, index) => (
              <li key={index} className="flex items-start text-sm text-gray-600 bg-blue-50 p-3 rounded-md border border-blue-200">
                <span className="flex-shrink-0 mr-2.5 mt-0.5 text-blue-500">💡</span>
                <span>{advice}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};
