
import React from 'react';

export const Spinner: React.FC = () => {
  return (
    <div className="flex justify-center items-center py-10">
      <div className="animate-spin rounded-full h-12 w-12 border-t-4 border-b-4 border-purple-600"></div>
      <p className="ml-4 text-lg text-gray-600">분석 중입니다. 잠시만 기다려주세요...</p>
    </div>
  );
};
