
import React from 'react';
import { NutrientInfo, UserTargets, StoredMealRecord } from '../types';

// Icons - Define or import if they are common
const ChevronLeftIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="15 18 9 12 15 6"></polyline>
  </svg>
);

const ChevronRightIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="9 18 15 12 9 6"></polyline>
  </svg>
);

const CalendarDaysIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="24" height="24">
    <path fillRule="evenodd" d="M3.75 12a.75.75 0 0 1 .75-.75h15a.75.75 0 0 1 0 1.5h-15a.75.75 0 0 1-.75-.75Zm.75 2.25a.75.75 0 0 0 0 1.5h13.5a.75.75 0 0 0 0-1.5H4.5Zm0 3a.75.75 0 0 0 0 1.5h13.5a.75.75 0 0 0 0-1.5H4.5Z" clipRule="evenodd" />
    <path fillRule="evenodd" d="M2.25 6.75A.75.75 0 0 1 3 6h18a.75.75 0 0 1 .75.75v11.25a3 3 0 0 1-3 3H5.25a3 3 0 0 1-3-3V6.75ZM18.75 7.5H5.25a1.5 1.5 0 0 0-1.5 1.5V18a1.5 1.5 0 0 0 1.5 1.5h13.5a1.5 1.5 0 0 0 1.5-1.5V9A1.5 1.5 0 0 0 18.75 7.5Z" clipRule="evenodd" />
    <path fillRule="evenodd" d="M7.5 3a.75.75 0 0 0-1.5 0V6A.75.75 0 0 0 7.5 6V3Zm9-1.5A.75.75 0 0 1 18 2.25v2.25a.75.75 0 0 1-1.5 0V2.25a.75.75 0 0 1 .75-.75Z" clipRule="evenodd" />
  </svg>
);

const ExclamationTriangleIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="24" height="24">
      <path fillRule="evenodd" d="M9.401 3.003c1.155-2 4.043-2 5.197 0l7.519 13.007a3.001 3.001 0 0 1-2.598 4.501H4.48a3.001 3.001 0 0 1-2.598-4.501L9.4 3.003ZM12 8.25a.75.75 0 0 1 .75.75v3.75a.75.75 0 0 1-1.5 0V9a.75.75 0 0 1 .75-.75Zm0 8.25a.75.75 0 1 0 0-1.5.75.75 0 0 0 0 1.5Z" clipRule="evenodd" />
    </svg>
);

interface DailyIntakeSummaryProps {
  selectedDate: Date;
  dailyTotals: NutrientInfo;
  userTargets: UserTargets;
  onDateChange: (date: Date) => void;
  storedMealsForSelectedDate: StoredMealRecord[];
}

const NutrientBar: React.FC<{ label: string; value: number; target: number; unit: string }> = ({ label, value, target, unit }) => {
    const percentage = target > 0 ? Math.min((value / target) * 100, 100) : 0;
    const isOver = target > 0 && value > target;
    
    let barColor = 'bg-green-500'; 
    if (label === "칼로리") {
        if (value > target * 1.05) barColor = 'bg-red-500'; 
        else if (value < target * 0.8) barColor = 'bg-yellow-400';
        else barColor = 'bg-green-500'; 
    } else { 
        if (value > target * 1.3) barColor = 'bg-red-500'; 
        else if (value < target * 0.7) barColor = 'bg-yellow-400'; 
        else if (value < target * 0.9 || value > target * 1.1) barColor = 'bg-blue-400'; 
        else barColor = 'bg-green-500';
    }
    if (target === 0 && value > 0) barColor = 'bg-blue-400';
    if (target === 0 && value === 0) barColor = 'bg-gray-300';

    return (
        <div>
            <div className="flex justify-between text-sm mb-0.5">
                <span className="font-medium text-gray-700">{label}</span>
                <span className="text-gray-600">
                    {value.toFixed(0)}{unit} / {target > 0 ? target.toFixed(0) : '-'}{unit}
                    {isOver && label === "칼로리" && value > target * 1.05 && <span className="text-red-500 ml-1 font-semibold">(초과)</span>}
                </span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-3">
                <div 
                    className={`${barColor} h-3 rounded-full transition-all duration-500 ease-out`}
                    style={{ width: `${isOver && label === "칼로리" ? 100 : (target > 0 ? percentage : (value > 0 ? 100 : 0))}%` }}
                    role="progressbar"
                    aria-valuenow={value}
                    aria-valuemin={0}
                    aria-valuemax={target > 0 ? target : undefined} 
                    aria-label={`${label} 섭취량`}
                ></div>
            </div>
        </div>
    );
};

export const DailyIntakeSummary: React.FC<DailyIntakeSummaryProps> = ({ selectedDate, dailyTotals, userTargets, onDateChange, storedMealsForSelectedDate }) => {
  const handleDayChange = (amount: number) => {
    const newDate = new Date(selectedDate);
    newDate.setDate(selectedDate.getDate() + amount);
    onDateChange(newDate);
  };

  const datePart = selectedDate.toLocaleDateString('ko-KR', {
    year: 'numeric', month: 'long', day: 'numeric'
  });
  const weekdayPart = selectedDate.toLocaleDateString('ko-KR', { weekday: 'short' });
  const formattedDate = `${datePart} (${weekdayPart})`;


  const today = new Date();
  today.setHours(0,0,0,0); 
  const normalizedSelectedDate = new Date(selectedDate);
  normalizedSelectedDate.setHours(0,0,0,0);

  const isToday = normalizedSelectedDate.getTime() === today.getTime();
  const isFutureDate = normalizedSelectedDate > today;

  // Determine warning messages
  const warningMessages: string[] = [];
  if (userTargets.calories > 0 && dailyTotals.calories > userTargets.calories * 1.05) {
      warningMessages.push(`총 칼로리(${dailyTotals.calories.toFixed(0)}kcal)가 목표치(${userTargets.calories.toFixed(0)}kcal)를 초과했습니다.`);
  }
  if (userTargets.protein > 0 && dailyTotals.protein > userTargets.protein * 1.3) {
      warningMessages.push(`단백질(${dailyTotals.protein.toFixed(0)}g) 섭취가 목표치(${userTargets.protein.toFixed(0)}g)보다 많습니다.`);
  }
  if (userTargets.fat > 0 && dailyTotals.fat > userTargets.fat * 1.3) {
      warningMessages.push(`지방(${dailyTotals.fat.toFixed(0)}g) 섭취가 목표치(${userTargets.fat.toFixed(0)}g)보다 많습니다.`);
  }
  if (userTargets.carbs > 0 && dailyTotals.carbs > userTargets.carbs * 1.3) {
      warningMessages.push(`탄수화물(${dailyTotals.carbs.toFixed(0)}g) 섭취가 목표치(${userTargets.carbs.toFixed(0)}g)보다 많습니다.`);
  }
  const showWarning = warningMessages.length > 0 && storedMealsForSelectedDate.length > 0;


  return (
    <div className="mt-8 p-4 md:p-6 bg-white shadow-xl rounded-lg border border-gray-200">
      <h2 className="text-xl md:text-2xl font-semibold text-gray-800 mb-6 flex items-center">
        <CalendarDaysIcon className="w-6 h-6 md:w-7 md:h-7 mr-2 text-indigo-600" />
        일일 섭취량 요약
      </h2>

      {/* Date Navigator */}
      <div className="flex items-center justify-between mb-6">
        <button 
          onClick={() => handleDayChange(-1)} 
          className="p-2.5 bg-indigo-500 text-white rounded-md hover:bg-indigo-600 transition focus:outline-none focus:ring-2 focus:ring-indigo-400"
          aria-label="이전 날짜 요약 보기"
        >
          <ChevronLeftIcon className="w-5 h-5" />
        </button>
        <div className="text-center">
            <h3 className="text-md md:text-lg font-semibold text-indigo-700">{formattedDate}</h3>
            {!isToday && (
                 <button 
                    onClick={() => onDateChange(new Date())} 
                    className="text-xs text-indigo-500 hover:underline focus:outline-none"
                    aria-label="오늘 날짜로 이동"
                >
                    (오늘로 가기)
                </button>
            )}
        </div>
        <button 
          onClick={() => handleDayChange(1)} 
          className="p-2.5 bg-indigo-500 text-white rounded-md hover:bg-indigo-600 transition focus:outline-none focus:ring-2 focus:ring-indigo-400 disabled:opacity-50"
          aria-label="다음 날짜 요약 보기"
          disabled={isFutureDate || isToday} 
        >
          <ChevronRightIcon className="w-5 h-5" />
        </button>
      </div>
      
      {storedMealsForSelectedDate.length === 0 ? (
        <p className="text-gray-600 text-center py-6 bg-gray-50 rounded-md border border-gray-100">이 날짜에 기록된 식사가 없습니다.</p>
      ) : (
        <>
          {/* Intake Warning Messages */}
          {showWarning && (
            <div className="mb-6 p-3.5 bg-red-50 border-l-4 border-red-500 text-red-700 rounded-md shadow">
              <div className="flex">
                <div className="flex-shrink-0">
                    <ExclamationTriangleIcon className="h-5 w-5 text-red-400" aria-hidden="true" />
                </div>
                <div className="ml-3">
                    <h4 className="font-semibold text-sm text-red-800 mb-1">일일 섭취량 경고</h4>
                    <ul className="list-disc list-inside text-xs text-red-700 space-y-0.5">
                    {warningMessages.map((msg, idx) => <li key={idx}>{msg}</li>)}
                    </ul>
                    <p className="text-xs mt-1.5 text-red-600">균형 잡힌 식단과 활동으로 건강을 관리하세요.</p>
                </div>
              </div>
            </div>
          )}

          {/* Totals against Targets */}
          <div className="space-y-4 mb-6 p-4 bg-indigo-50 rounded-md border border-indigo-200 shadow-sm">
              <h4 className="text-md font-semibold text-gray-700 mb-1">총 섭취량 vs 목표량:</h4>
              <NutrientBar label="칼로리" value={dailyTotals.calories} target={userTargets.calories} unit="kcal" />
              <NutrientBar label="단백질" value={dailyTotals.protein} target={userTargets.protein} unit="g" />
              <NutrientBar label="탄수화물" value={dailyTotals.carbs} target={userTargets.carbs} unit="g" />
              <NutrientBar label="지방" value={dailyTotals.fat} target={userTargets.fat} unit="g" />
          </div>

          {/* Individual Meals for the day */}
          <div>
              <h4 className="text-md font-semibold text-gray-700 mb-3">이 날의 식사 기록:</h4>
              <ul className="space-y-3">
                  {storedMealsForSelectedDate.map(meal => (
                      <li key={meal.id} className="p-3.5 bg-gray-100 rounded-md shadow-sm border border-gray-200 hover:shadow-md transition-shadow">
                          <div className="flex justify-between items-center mb-1">
                              <span className="font-medium text-indigo-700 text-sm">
                                {meal.mealType || '기타 식사'}
                                {meal.foodNameHint && <span className="text-gray-500 font-normal"> ({meal.foodNameHint})</span>}
                              </span>
                              <span className="text-xs text-gray-600 bg-white px-2 py-0.5 rounded-full border border-gray-300">{meal.analysis.totalNutrients.calories.toFixed(0)} kcal</span>
                          </div>
                          <details className="mt-1 text-xs text-gray-600">
                              <summary className="cursor-pointer hover:underline text-indigo-600 focus:outline-none focus:ring-1 focus:ring-indigo-300 rounded-sm">상세 영양 정보 보기</summary>
                              <div className="pt-2 pl-1 space-y-0.5">
                                  <p><strong>총:</strong> 단: {meal.analysis.totalNutrients.protein.toFixed(1)}g, 탄: {meal.analysis.totalNutrients.carbs.toFixed(1)}g, 지: {meal.analysis.totalNutrients.fat.toFixed(1)}g</p>
                                  {meal.analysis.items.map((foodItem, idx) => (
                                    <p key={idx} className="ml-2 text-gray-500">&bull; {foodItem.name}: {foodItem.calories.toFixed(0)} kcal (단: {foodItem.protein.toFixed(1)}g, 탄: {foodItem.carbs.toFixed(1)}g, 지: {foodItem.fat.toFixed(1)}g)</p>
                                  ))}
                              </div>
                          </details>
                      </li>
                  ))}
              </ul>
          </div>
        </>
      )}
    </div>
  );
};
