
import React, { useRef } from 'react';
import { MealType, UserTargets, UserProfile, Gender } from '../types';
import { MEAL_TYPES } from '../constants';
import { ImagePreview } from './ImagePreview';

// Icon components (simple SVGs)
const CalendarIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line>
  </svg>
);

const ClockIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline>
  </svg>
);

const ChevronLeftIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="15 18 9 12 15 6"></polyline>
  </svg>
);

const ChevronRightIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="9 18 15 12 9 6"></polyline>
  </svg>
);

const CameraIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
 <svg {...props} xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"></path>
    <circle cx="12" cy="13" r="3"></circle>
  </svg>
);

const PencilSquareIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="24" height="24">
    <path d="M21.731 2.269a2.625 2.625 0 0 0-3.712 0l-1.157 1.157 3.712 3.712 1.157-1.157a2.625 2.625 0 0 0 0-3.712ZM19.513 8.199l-3.712-3.712-8.4 8.4a5.25 5.25 0 0 0-1.32 2.214l-.8 2.685a.75.75 0 0 0 .933.933l2.685-.8a5.25 5.25 0 0 0 2.214-1.32l8.4-8.4Z" />
    <path d="M5.25 5.25a3 3 0 0 0-3 3v10.5a3 3 0 0 0 3 3h10.5a3 3 0 0 0 3-3V13.5a.75.75 0 0 0-1.5 0v5.25a1.5 1.5 0 0 1-1.5 1.5H5.25a1.5 1.5 0 0 1-1.5-1.5V8.25a1.5 1.5 0 0 1 1.5-1.5h5.25a.75.75 0 0 0 0-1.5H5.25Z" />
  </svg>
);

const UserIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="24" height="24">
    <path fillRule="evenodd" d="M18.685 19.097A9.723 9.723 0 0 0 21.75 12c0-5.385-4.365-9.75-9.75-9.75S2.25 6.615 2.25 12a9.723 9.723 0 0 0 3.065 7.097A9.716 9.716 0 0 0 12 21.75a9.716 9.716 0 0 0 6.685-2.653Zm-12.54-1.285A7.486 7.486 0 0 1 12 15a7.486 7.486 0 0 1 5.855 2.812A8.224 8.224 0 0 1 12 20.25a8.224 8.224 0 0 1-5.855-2.438ZM15.75 9a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0Z" clipRule="evenodd" />
  </svg>
);

const TrophyIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="24" height="24">
      <path fillRule="evenodd" d="M11.25 3a.75.75 0 0 1 .75.75V4.5h.75a.75.75 0 0 1 0 1.5H12v.75a.75.75 0 0 1-1.5 0V6h-.75a.75.75 0 0 1 0-1.5H10.5V3.75a.75.75 0 0 1 .75-.75ZM7.5 7.5A.75.75 0 0 0 6 8.25v8.064a3.75 3.75 0 0 0 2.28 3.483l.794.444a.75.75 0 0 0 .852-.67V20.25h3.15v-.674a.75.75 0 0 0 .852-.67l.794-.444a3.75 3.75 0 0 0 2.28-3.483V8.25A.75.75 0 0 0 16.5 7.5h-9ZM9 9.75a.75.75 0 0 1 .75-.75h4.5a.75.75 0 0 1 0 1.5h-4.5a.75.75 0 0 1-.75-.75Zm.75 2.25a.75.75 0 0 0 0 1.5h3a.75.75 0 0 0 0-1.5h-3Z" clipRule="evenodd" />
    </svg>
  );
  

interface PhotoUploadFormProps {
  currentDate: Date;
  onDateChange: (date: Date) => void;
  mealTime: string;
  onTimeChange: (time: string) => void;
  mealType: MealType | '';
  onMealTypeChange: (type: MealType | '') => void;
  imageFiles: File[];
  onImageFilesChange: (files: File[]) => void;
  foodNameHint: string;
  onFoodNameHintChange: (hint: string) => void;
  onSubmit: () => void;
  isLoading: boolean;
  userProfile: UserProfile | null;
  onUserProfileChange: (field: keyof UserProfile, value: string | number | Gender) => void;
  userTargets: UserTargets;
  targetAdjustmentMessage?: string | null;
}

export const PhotoUploadForm: React.FC<PhotoUploadFormProps> = ({
  currentDate, onDateChange, mealTime, onTimeChange, mealType, onMealTypeChange,
  imageFiles, onImageFilesChange, foodNameHint, onFoodNameHintChange,
  onSubmit, isLoading, userProfile, onUserProfileChange, userTargets, targetAdjustmentMessage
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const dateInputRef = useRef<HTMLInputElement>(null);
  const timeInputRef = useRef<HTMLInputElement>(null);

  const handleDayChange = (amount: number) => {
    const newDate = new Date(currentDate);
    newDate.setDate(currentDate.getDate() + amount);
    onDateChange(newDate);
  };

  const datePart = currentDate.toLocaleDateString('ko-KR', {
    year: 'numeric', month: 'long', day: 'numeric'
  });
  const weekdayPart = currentDate.toLocaleDateString('ko-KR', { weekday: 'short' });
  const formattedDate = `${datePart} (${weekdayPart})`;

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files) {
      onImageFilesChange(Array.from(event.target.files));
    }
  };
  
  const handleRemoveImage = (index: number) => {
    onImageFilesChange(imageFiles.filter((_, i) => i !== index));
  };

  const isProfileComplete = userProfile && userProfile.gender && userProfile.age && userProfile.height && userProfile.weight;


  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold text-gray-700 mb-4 flex items-center">
        <PencilSquareIcon className="w-6 h-6 mr-2 text-purple-600" />
        식사 기록 및 분석
      </h2>
      
      {/* Date Input */}
      <div>
        <label htmlFor="meal-date-input" className="block text-sm font-medium text-gray-600 mb-1">날짜</label>
        <div className="flex items-center space-x-2">
          <button 
            onClick={() => handleDayChange(-1)} 
            className="p-2.5 bg-indigo-500 text-white rounded-md hover:bg-indigo-600 transition duration-150 focus:outline-none focus:ring-2 focus:ring-indigo-400"
            aria-label="이전 날짜"
          >
            <ChevronLeftIcon />
          </button>
          <div className="flex-grow relative date-input-container px-2">
            <input 
              type="date"
              id="meal-date-input"
              ref={dateInputRef}
              value={currentDate.toISOString().split('T')[0]}
              onChange={(e) => onDateChange(new Date(e.target.value))}
              className="w-full p-2.5 pr-10 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 text-transparent appearance-none"
              aria-label="날짜 선택"
            />
            <span 
              className="absolute inset-0 flex items-center justify-center text-gray-700 pointer-events-none whitespace-nowrap overflow-hidden text-ellipsis p-2.5 pr-10"
              aria-hidden="true"
            >
              {formattedDate}
            </span>
            <button 
              type="button" 
              onClick={() => dateInputRef.current?.showPicker()} 
              className="absolute right-3 top-1/2 -translate-y-1/2 text-indigo-600 hover:text-indigo-700"
              aria-label="날짜 선택 달력 열기"
            >
                <CalendarIcon className="w-5 h-5" />
            </button>
          </div>
          <button 
            onClick={() => handleDayChange(1)} 
            className="p-2.5 bg-indigo-500 text-white rounded-md hover:bg-indigo-600 transition duration-150 focus:outline-none focus:ring-2 focus:ring-indigo-400"
            aria-label="다음 날짜"
          >
            <ChevronRightIcon />
          </button>
        </div>
      </div>

      {/* Time Input */}
      <div>
        <label htmlFor="meal-time" className="block text-sm font-medium text-gray-600 mb-1">시간</label>
        <div className="relative time-input-container">
            <input
            type="time"
            id="meal-time"
            ref={timeInputRef}
            value={mealTime}
            onChange={(e) => onTimeChange(e.target.value)}
            className="w-full p-2.5 pr-10 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 text-gray-700 appearance-none text-center"
            aria-label="시간 선택"
            />
            <button 
              type="button" 
              onClick={() => timeInputRef.current?.showPicker()} 
              className="absolute right-3 top-1/2 -translate-y-1/2 text-indigo-600 hover:text-indigo-700"
              aria-label="시간 선택 도구 열기"
            >
                <ClockIcon className="w-5 h-5"/>
            </button>
        </div>
      </div>
      
      {/* Meal Type */}
      <div>
        <label htmlFor="meal-type" className="block text-sm font-medium text-gray-600 mb-1">구분</label>
        <select
          id="meal-type"
          value={mealType}
          onChange={(e) => onMealTypeChange(e.target.value as MealType | '')}
          className="w-full p-2.5 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 text-gray-700"
        >
          <option value="">선택하세요</option>
          {MEAL_TYPES.map(type => <option key={type} value={type}>{type}</option>)}
        </select>
      </div>

      {/* Image Upload */}
      <div>
        <label htmlFor="file-upload-input" className="block text-sm font-medium text-gray-600 mb-1">사진 업로드</label>
        <div
          onClick={() => fileInputRef.current?.click()}
          onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') fileInputRef.current?.click(); }}
          role="button"
          tabIndex={0}
          aria-labelledby="file-upload-label"
          className="mt-1 flex justify-center items-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md cursor-pointer hover:border-indigo-500 transition duration-150"
        >
          <div className="space-y-1 text-center" id="file-upload-label">
            <CameraIcon className="mx-auto h-12 w-12 text-gray-400" />
            <p className="text-sm text-gray-600">
              클릭하여 이미지 선택 또는 카메라로 촬영
            </p>
            <p className="text-xs text-gray-500">PNG, JPG, GIF up to 10MB</p>
          </div>
        </div>
        <input
          type="file"
          id="file-upload-input"
          ref={fileInputRef}
          multiple
          accept="image/*"
          onChange={handleImageUpload}
          className="hidden"
          aria-label="사진 파일 선택 또는 카메라로 촬영"
        />
        {imageFiles.length > 0 && (
          <div className="mt-4 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {imageFiles.map((file, index) => (
              <ImagePreview key={index} file={file} onRemove={() => handleRemoveImage(index)} />
            ))}
          </div>
        )}
      </div>

      {/* Food Name Hint */}
      <div>
        <label htmlFor="food-name-hint" className="block text-sm font-medium text-gray-600 mb-1">음식 이름 (선택사항)</label>
        <input
          type="text"
          id="food-name-hint"
          value={foodNameHint}
          onChange={(e) => onFoodNameHintChange(e.target.value)}
          placeholder="예: 맥도날드 빅맥"
          className="w-full p-2.5 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 text-gray-700"
        />
      </div>

      {/* User Profile Inputs */}
      <div className="pt-4 border-t border-gray-200">
        <h3 className="text-md font-semibold text-gray-700 mb-3 flex items-center">
            <UserIcon className="w-5 h-5 mr-2 text-purple-600" />
            나의 프로필
        </h3>
        <div className="grid grid-cols-2 gap-x-4 gap-y-3 mb-4">
            <div>
                <label htmlFor="profile-gender" className="block text-xs font-medium text-gray-600">성별</label>
                <select 
                    id="profile-gender" 
                    value={userProfile?.gender || ''} 
                    onChange={(e) => onUserProfileChange('gender', e.target.value as Gender)} 
                    className="mt-1 w-full p-2.5 border border-gray-300 rounded-md shadow-sm text-gray-700 focus:ring-indigo-500 focus:border-indigo-500 text-sm"
                >
                    <option value="">선택</option>
                    <option value={Gender.Male}>남성</option>
                    <option value={Gender.Female}>여성</option>
                </select>
            </div>
            <div>
                <label htmlFor="profile-age" className="block text-xs font-medium text-gray-600">나이 (세)</label>
                <input type="number" id="profile-age" value={userProfile?.age || ''} onChange={(e) => onUserProfileChange('age', parseInt(e.target.value) || '')} className="mt-1 w-full p-2.5 border border-gray-300 rounded-md shadow-sm text-gray-700 focus:ring-indigo-500 focus:border-indigo-500 text-sm" placeholder="예: 30"/>
            </div>
            <div>
                <label htmlFor="profile-height" className="block text-xs font-medium text-gray-600">키 (cm)</label>
                <input type="number" id="profile-height" value={userProfile?.height || ''} onChange={(e) => onUserProfileChange('height', parseInt(e.target.value) || '')} className="mt-1 w-full p-2.5 border border-gray-300 rounded-md shadow-sm text-gray-700 focus:ring-indigo-500 focus:border-indigo-500 text-sm" placeholder="예: 170"/>
            </div>
            <div>
                <label htmlFor="profile-weight" className="block text-xs font-medium text-gray-600">현재 체중 (kg)</label>
                <input type="number" id="profile-weight" value={userProfile?.weight || ''} onChange={(e) => onUserProfileChange('weight', parseInt(e.target.value) || '')} className="mt-1 w-full p-2.5 border border-gray-300 rounded-md shadow-sm text-gray-700 focus:ring-indigo-500 focus:border-indigo-500 text-sm" placeholder="예: 65"/>
            </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-3">
             <div>
                <label htmlFor="profile-target-weight" className="block text-xs font-medium text-gray-600">목표 체중 (kg, 선택)</label>
                <input type="number" id="profile-target-weight" value={userProfile?.targetWeight || ''} onChange={(e) => onUserProfileChange('targetWeight', parseInt(e.target.value) || '')} className="mt-1 w-full p-2.5 border border-gray-300 rounded-md shadow-sm text-gray-700 focus:ring-indigo-500 focus:border-indigo-500 text-sm" placeholder="예: 60"/>
            </div>
            <div className="md:col-span-2">
                <label htmlFor="profile-aspirations" className="block text-xs font-medium text-gray-600">나의 목표/희망사항 (선택)</label>
                <textarea 
                    id="profile-aspirations" 
                    value={userProfile?.aspirations || ''} 
                    onChange={(e) => onUserProfileChange('aspirations', e.target.value)} 
                    rows={2}
                    className="mt-1 w-full p-2.5 border border-gray-300 rounded-md shadow-sm text-gray-700 focus:ring-indigo-500 focus:border-indigo-500 text-sm" 
                    placeholder="예: 건강한 식습관 형성, 체지방 감소, 근력 증가">
                </textarea>
            </div>
        </div>
      </div>

      {/* Display Calculated User Targets */}
      <div className="pt-4 border-t border-gray-200">
        <h3 className="text-md font-semibold text-gray-700 mb-2 flex items-center">
            <TrophyIcon className="w-5 h-5 mr-2 text-purple-600" />
            나의 일일 권장 섭취량
        </h3>
        {!isProfileComplete ? (
            <p className="text-sm text-gray-500 bg-yellow-50 p-3 rounded-md border border-yellow-200">
                나의 프로필(성별, 나이, 키, 몸무게)을 모두 입력하시면 개인 맞춤 권장 섭취량이 계산됩니다. 현재는 기본 목표치가 적용됩니다.
            </p>
        ) : (
            <>
                <div className="grid grid-cols-2 gap-x-4 gap-y-2 p-3 bg-indigo-50 rounded-md border border-indigo-200">
                    <div className="text-sm text-gray-700"><strong>칼로리:</strong> {userTargets.calories.toFixed(0)} kcal</div>
                    <div className="text-sm text-gray-700"><strong>단백질:</strong> {userTargets.protein.toFixed(0)} g</div>
                    <div className="text-sm text-gray-700"><strong>탄수화물:</strong> {userTargets.carbs.toFixed(0)} g</div>
                    <div className="text-sm text-gray-700"><strong>지방:</strong> {userTargets.fat.toFixed(0)} g</div>
                </div>
                {targetAdjustmentMessage && (
                    <p className="mt-2 text-xs text-indigo-600 bg-indigo-100 p-2 rounded-md border border-indigo-200">
                        💡 {targetAdjustmentMessage}
                    </p>
                )}
            </>
        )}
      </div>

      {/* Submit Button */}
      <button
        onClick={onSubmit}
        disabled={isLoading || imageFiles.length === 0}
        className="w-full mt-6 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-semibold py-3 px-4 rounded-md shadow-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition duration-150 ease-in-out disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {isLoading ? '분석 중...' : '분석 시작'}
      </button>
    </div>
  );
};
