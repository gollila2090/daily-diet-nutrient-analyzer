
import React, { useState, useCallback, useEffect, useRef } from 'react';
import { GoogleGenAI } from "@google/genai";
import { Header } from './components/Header';
import { PhotoUploadForm } from './components/PhotoUploadForm';
import { AnalysisDisplay } from './components/AnalysisDisplay';
import { ExerciseRecommender } from './components/ExerciseRecommender';
import { Spinner } from './components/Spinner';
import { DailyIntakeSummary } from './components/DailyIntakeSummary';
import { NutrientInfo, AnalyzedFoodItem, AnalysisResult, ExerciseRecommendation, MealType, UserTargets, UserProfile, Gender, StoredMealRecord } from './types';
import { GEMINI_MODEL_TEXT, GEMINI_MODEL_VISION } from './constants';

// Constants for TDEE adjustment
const CALORIE_DEFICIT_FOR_WEIGHT_LOSS = 500;
const CALORIE_SURPLUS_FOR_WEIGHT_GAIN = 300;
const MIN_ACTIVITY_FACTOR_FOR_BMR_FLOOR = 1.2;


// Helper function to sanitize and parse JSON
function sanitizeAndParseJson<T>(jsonStr: string, contextErrorMsg: string): T {
  let originalTrimmedStr = jsonStr.trim();

  // First, try to remove markdown fences if present
  const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
  const fenceMatch = originalTrimmedStr.match(fenceRegex);
  if (fenceMatch && fenceMatch[2]) {
    originalTrimmedStr = fenceMatch[2].trim();
  }

  try {
    return JSON.parse(originalTrimmedStr) as T;
  } catch (initialError: any) {
    console.warn(`Initial JSON.parse failed for ${contextErrorMsg}: ${initialError.message}. Raw (after fence removal): "${originalTrimmedStr}". Attempting sanitization.`);

    let sanitized = "";
    let inString = false;
    let escapeNext = false;

    for (let i = 0; i < originalTrimmedStr.length; i++) {
      const char = originalTrimmedStr[i];

      if (escapeNext) {
        sanitized += char;
        escapeNext = false;
        continue;
      }

      if (char === '\\') {
        sanitized += char;
        escapeNext = true;
        continue;
      }

      if (char === '"') {
        inString = !inString;
        sanitized += char;
        continue;
      }

      if (!inString) {
        // Allow a broader set of characters that might appear in valid numbers or keywords,
        // but try to exclude those likely to be extraneous non-JSON text.
        // Simplified regex: allow JSON structural chars, whitespace, alphanumeric for keywords/numbers, and common number chars.
        if (char.match(/[{}[\]:,.\sA-Za-z0-9\-\+eE]/i)) { 
          sanitized += char;
        }
      } else {
        sanitized += char;
      }
    }
    
    const finalSanitizedStr = sanitized.trim();

    try {
      const parsed = JSON.parse(finalSanitizedStr);
      console.log(`Successfully parsed ${contextErrorMsg} after sanitization.`);
      return parsed as T;
    } catch (finalError: any) {
      console.error(`JSON.parse still failed for ${contextErrorMsg} after sanitization: ${finalError.message}. Sanitized string: "${finalSanitizedStr}". Original string (after fence removal): "${originalTrimmedStr}"`);
      const wrappedError = new Error(`Failed to parse ${contextErrorMsg} even after sanitization. Parser error: ${finalError.message}. Original error: ${initialError.message}.`);
      (wrappedError as any).originalString = originalTrimmedStr;
      (wrappedError as any).sanitizedString = finalSanitizedStr;
      (wrappedError as any).originalError = initialError;
      (wrappedError as any).finalError = finalError;
      throw wrappedError;
    }
  }
}


const App: React.FC = () => {
  const [currentDate, setCurrentDate] = useState<Date>(new Date());
  const [mealTime, setMealTime] = useState<string>(new Date().toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit', hour12: false }).replace('24:', '00:'));
  const [mealType, setMealType] = useState<MealType | ''>('');
  const [imageFiles, setImageFiles] = useState<File[]>([]);
  const [foodNameHint, setFoodNameHint] = useState<string>('');
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [exerciseRecommendations, setExerciseRecommendations] = useState<ExerciseRecommendation | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [userTargets, setUserTargets] = useState<UserTargets>({ calories: 2000, protein: 75, carbs: 250, fat: 65 }); 
  const [targetAdjustmentMessage, setTargetAdjustmentMessage] = useState<string | null>(null);
  const [healthAdvice, setHealthAdvice] = useState<string[]>([]);

  const [storedMeals, setStoredMeals] = useState<StoredMealRecord[]>([]);
  const [summaryDate, setSummaryDate] = useState<Date>(new Date());

  const ai = useRef<GoogleGenAI | null>(null);

  useEffect(() => {
    if (process.env.API_KEY) {
      ai.current = new GoogleGenAI({ apiKey: process.env.API_KEY });
    } else {
      setError("API 키가 설정되지 않았습니다. 환경 변수 API_KEY를 설정해주세요.");
      console.error("API_KEY is not set in environment variables.");
    }

    const savedProfile = localStorage.getItem('userProfile');
    if (savedProfile) {
      try {
        const parsedProfile = JSON.parse(savedProfile);
        setUserProfile({
            ...parsedProfile,
            targetWeight: parsedProfile.targetWeight || '', 
            aspirations: parsedProfile.aspirations || '' 
        });
      } catch (e) {
        console.error("Failed to parse userProfile from localStorage", e);
        localStorage.removeItem('userProfile');
      }
    }

    const loadedMeals = localStorage.getItem('storedMeals');
    if (loadedMeals) {
       try {
        setStoredMeals(JSON.parse(loadedMeals));
      } catch (e) {
        console.error("Failed to parse storedMeals from localStorage", e);
        localStorage.removeItem('storedMeals');
      }
    }
  }, []);

  useEffect(() => {
    if (userProfile) {
        localStorage.setItem('userProfile', JSON.stringify(userProfile));
    }
  }, [userProfile]);

  useEffect(() => {
    localStorage.setItem('storedMeals', JSON.stringify(storedMeals));
  }, [storedMeals]);

  useEffect(() => {
    let newTargetAdjustmentMessage: string | null = null;
    if (userProfile && userProfile.gender && userProfile.age && userProfile.height && userProfile.weight) {
      const { gender, age, height, weight, targetWeight } = userProfile;
      
      const numAge = Number(age);
      const numHeight = Number(height);
      const numCurrentWeight = Number(weight);
      const numTargetWeight = targetWeight ? Number(targetWeight) : null;

      if (numAge > 0 && numHeight > 0 && numCurrentWeight > 0 && gender) {
        let bmr: number;
        if (gender === Gender.Male) {
          bmr = (10 * numCurrentWeight) + (6.25 * numHeight) - (5 * numAge) + 5;
        } else { 
          bmr = (10 * numCurrentWeight) + (6.25 * numHeight) - (5 * numAge) - 161;
        }

        const activityFactor = 1.375; 
        let tdee = bmr * activityFactor;
        
        if (numTargetWeight && numTargetWeight > 0 && numTargetWeight !== numCurrentWeight) {
          if (numTargetWeight < numCurrentWeight) { // Weight loss
            const adjustedTDEE = tdee - CALORIE_DEFICIT_FOR_WEIGHT_LOSS;
            tdee = Math.max(adjustedTDEE, bmr * MIN_ACTIVITY_FACTOR_FOR_BMR_FLOOR); 
            newTargetAdjustmentMessage = `체중 감량 목표를 위해 일일 권장 칼로리가 약 ${CALORIE_DEFICIT_FOR_WEIGHT_LOSS}kcal 조정되었습니다.`;
          } else { // Weight gain
            tdee = tdee + CALORIE_SURPLUS_FOR_WEIGHT_GAIN;
            newTargetAdjustmentMessage = `체중 증가 목표를 위해 일일 권장 칼로리가 약 ${CALORIE_SURPLUS_FOR_WEIGHT_GAIN}kcal 조정되었습니다.`;
          }
        }
        
        const proteinGrams = numCurrentWeight * 1.6; 
        const proteinCalories = proteinGrams * 4;
        
        const fatCalories = tdee * 0.25; 
        const fatGrams = fatCalories / 9;

        const carbCalories = tdee - proteinCalories - fatCalories;
        const carbGrams = carbCalories / 4;

        setUserTargets({
          calories: Math.round(tdee),
          protein: Math.round(proteinGrams),
          carbs: Math.round(carbGrams),
          fat: Math.round(fatGrams),
        });
      } else {
         setUserTargets({ calories: 2000, protein: 75, carbs: 250, fat: 65 });
      }
    } else {
      setUserTargets({ calories: 2000, protein: 75, carbs: 250, fat: 65 });
    }
    setTargetAdjustmentMessage(newTargetAdjustmentMessage);
  }, [userProfile]);

  const handleUserProfileChange = (field: keyof UserProfile, value: string | number | Gender) => {
    setUserProfile(prev => ({
        ...(prev || { gender: '', age: '', height: '', weight: '', targetWeight: '', aspirations: '' }),
        [field]: value 
    }));
  };

  const handleDateChange = (newDate: Date) => {
    setCurrentDate(newDate);
  };

  const handleTimeChange = (newTime: string) => {
    setMealTime(newTime);
  };

  const fileToGenerativePart = async (file: File): Promise<{ inlineData: { mimeType: string; data: string; } }> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        try {
          const result = reader.result as string;
          if (typeof result !== 'string' || !result.startsWith('data:')) {
            reject(new Error(`FileReader did not return a valid data URL for file ${file.name}.`));
            return;
          }
          const base64EncodedData = result.split(',')[1];
          if (typeof base64EncodedData !== 'string') {
             reject(new Error(`Could not extract base64 data from FileReader result for file ${file.name}.`));
             return;
          }
          resolve({
            inlineData: {
              mimeType: file.type,
              data: base64EncodedData,
            },
          });
        } catch (error: any) {
          reject(new Error(`Error processing file ${file.name}: ${error.message}`));
        }
      };
      reader.onerror = () => {
        reject(reader.error || new Error(`FileReader failed to read the file ${file.name}.`));
      };
      reader.readAsDataURL(file);
    });
  };

  const analyzeFood = useCallback(async () => {
    if (!ai.current) {
      setError("Gemini AI 클라이언트가 초기화되지 않았습니다.");
      return;
    }
    if (imageFiles.length === 0) {
      setError("분석할 이미지를 업로드해주세요.");
      return;
    }

    const analysisContext = {
        currentDate,
        mealTime,
        mealType,
        foodNameHint,
        userProfile: userProfile ? { ...userProfile } : null,
        userTargets: { ...userTargets },
        imageFiles: [...imageFiles] 
    };

    setIsLoading(true);
    setError(null);
    setAnalysisResult(null);
    setExerciseRecommendations(null);
    setHealthAdvice([]);

    try {
      const imageParts = await Promise.all(analysisContext.imageFiles.map(fileToGenerativePart));
      
      const simplifiedVisionPrompt = `Analyze the provided image(s) to identify all food items and estimate their nutritional information.
User food name hint (if any): "${analysisContext.foodNameHint}". Use this to refine analysis if provided.
Provide the response as a JSON array, where each object represents a food item and has the following structure:
{ "name": "Food Item Name (Korean)", "calories": number, "protein": number, "carbs": number, "fat": number }
Example: [{ "name": "사과, 중간 크기", "calories": 95, "protein": 0.5, "carbs": 25, "fat": 0.3 }]
Ensure the final response is strictly a valid JSON array. Do not include any text outside the JSON structure.`;

      const visionApiContentsParts: any[] = [ 
        ...imageParts,
        { text: simplifiedVisionPrompt }
      ];

      const response = await ai.current.models.generateContent({
        model: GEMINI_MODEL_VISION,
        contents: { parts: visionApiContentsParts },
        config: { temperature: 0.3 } // Removed responseMimeType: "application/json"
      });
      
      let parsedFoodItems: AnalyzedFoodItem[];
      try {
        parsedFoodItems = sanitizeAndParseJson<AnalyzedFoodItem[]>(response.text, "음식 분석 결과");
        if (!Array.isArray(parsedFoodItems) || !parsedFoodItems.every(item => 'name' in item && 'calories' in item && typeof item.name === 'string' && typeof item.calories === 'number')) {
            throw new Error("Incorrect JSON structure for food items after sanitization. Expected array of objects with 'name' (string) and 'calories' (number).");
        }
      } catch (e: any) {
        console.error("Failed to parse food items JSON:", e.message, "Raw response:", response.text);
        setError(`음식 분석 결과를 파싱하는 데 실패했습니다. API 응답 형식 오류일 수 있습니다. (오류: ${e.message})`);
        setIsLoading(false);
        return;
      }
      
      const totalNutrients: NutrientInfo = parsedFoodItems.reduce((acc, item) => ({
        calories: acc.calories + (Number(item.calories) || 0),
        protein: acc.protein + (Number(item.protein) || 0),
        carbs: acc.carbs + (Number(item.carbs) || 0),
        fat: acc.fat + (Number(item.fat) || 0),
      }), { calories: 0, protein: 0, carbs: 0, fat: 0 });

      setAnalysisResult({ items: parsedFoodItems, totalNutrients });

      if (parsedFoodItems.length > 0) {
        const newMealRecord: StoredMealRecord = {
          id: new Date().toISOString() + Math.random().toString(36).substring(2,9),
          date: analysisContext.currentDate.toISOString().slice(0, 10),
          mealType: analysisContext.mealType,
          foodNameHint: analysisContext.foodNameHint,
          analysis: { items: parsedFoodItems, totalNutrients },
        };
        setStoredMeals(prevMeals => [...prevMeals, newMealRecord]);
        setSummaryDate(new Date(analysisContext.currentDate)); 
      }

      console.log("--- Google Sheets Log Data ---");
      console.log("분석일시:", `${analysisContext.currentDate.toISOString().slice(0,10)} ${analysisContext.mealTime}`);
      console.log("식사 구분:", analysisContext.mealType);
      console.log("업로드된 음식명 (사용자 입력):", analysisContext.foodNameHint);
      console.log("분석된 음식 (Gemini):", JSON.stringify(parsedFoodItems));
      console.log("총 칼로리 (kcal):", totalNutrients.calories);
      console.log("총 단백질 (g):", totalNutrients.protein);
      console.log("총 탄수화물 (g):", totalNutrients.carbs);
      console.log("총 지방 (g):", totalNutrients.fat);
      console.log("사용자 정보 (Profile):", JSON.stringify(analysisContext.userProfile));
      console.log("권장 섭취량 (Targets):", JSON.stringify(analysisContext.userTargets));
      console.log("--- End Google Sheets Log Data ---");

      // Health Advice
      if (parsedFoodItems.length > 0) {
        try {
            let userProfileContext = "";
            if (analysisContext.userProfile) {
                userProfileContext += `사용자 프로필: 성별 ${analysisContext.userProfile.gender === Gender.Male ? '남성' : '여성'}, 나이 ${analysisContext.userProfile.age}세.`;
                if (analysisContext.userProfile.targetWeight) {
                    userProfileContext += ` 목표 체중은 ${analysisContext.userProfile.targetWeight}kg 입니다.`;
                } else {
                    userProfileContext += ` 목표 체중은 설정되지 않았습니다.`;
                }
                if (analysisContext.userProfile.aspirations) {
                    userProfileContext += ` 사용자의 주된 건강 목표 및 희망사항은 '${analysisContext.userProfile.aspirations}' 입니다.`;
                } else {
                    userProfileContext += ` 특별히 설정된 희망사항은 없습니다.`;
                }
            }

            const advicePrompt = `사용자가 방금 섭취한 식사의 영양 정보는 다음과 같습니다:
- 섭취한 총 칼로리: ${totalNutrients.calories.toFixed(0)} kcal
- 섭취한 총 단백질: ${totalNutrients.protein.toFixed(0)} g
- 섭취한 총 탄수화물: ${totalNutrients.carbs.toFixed(0)} g
- 섭취한 총 지방: ${totalNutrients.fat.toFixed(0)} g

사용자의 일일 전체 목표 섭취량은 다음과 같습니다:
- 목표 칼로리: ${analysisContext.userTargets.calories.toFixed(0)} kcal
- 목표 단백질: ${analysisContext.userTargets.protein.toFixed(0)} g
- 목표 탄수화물: ${analysisContext.userTargets.carbs.toFixed(0)} g
- 목표 지방: ${analysisContext.userTargets.fat.toFixed(0)} g

${userProfileContext}

이 식사가 사용자의 주된 목표인 '${analysisContext.userProfile?.aspirations || '전반적인 건강 관리'}' 달성에 어떤 영향을 미치는지, 그리고 설정된 목표 체중(${analysisContext.userProfile?.targetWeight || '미설정'}kg)을 고려하여 분석하고, 건강한 식습관을 위한 2-3가지 구체적이고 실천 가능한 조언을 한국어로 제공해주세요.

판단 기준:
1.  이 식사가 일일 목표량에 비해 얼마나 많은 부분을 차지하는지 고려해주세요. 
2.  칼로리, 단백질, 탄수화물, 지방의 균형을 평가해주세요. 
3.  단순히 이 식사의 칼로리가 일일 목표 칼로리보다 낮다고 해서 무조건 "훌륭하다"고 평가하지 마세요. 예를 들어, 식사 자체의 칼로리가 ${analysisContext.mealType === MealType.Snack ? '200~300' : '600~700'}kcal를 초과하거나 지방 함량이 25g을 초과하는 등 한 끼 식사로서 과도한 경우, 또는 영양 균형이 좋지 않은 경우에는 긍정적인 평가를 지양하고 개선점을 지적해주세요.
4.  사용자의 명시된 목표(목표 체중: ${analysisContext.userProfile?.targetWeight || '미설정'}kg, 희망사항: '${analysisContext.userProfile?.aspirations || '없음'}')를 최우선으로 고려하여 조언에 구체적으로 반영해주세요.
5.  조언은 부드럽고 격려하는 어조를 사용하되, 개선점에 대해서는 명확히 전달해야 합니다.

JSON 형식의 문자열 배열로 반환해주세요. 예: ["이 식사는 단백질 섭취에 도움이 되지만, 지방 함량이 다소 높으니 다음 식사에서 조절해보세요.", "오늘의 목표 칼로리를 고려할 때 적절한 양입니다.", "체중 감량 목표를 위해, 이 식사 후에는 가벼운 활동을 추가하는 것이 좋겠습니다."]
중요: 최종 응답은 반드시 유효한 JSON 형식의 문자열 배열이어야 하며, JSON.parse()로 오류 없이 파싱 가능해야 합니다. JSON 구조 외의 다른 텍스트, 설명, 주석 등은 절대 포함하지 마세요.`;

            const adviceResponse = await ai.current.models.generateContent({
                model: GEMINI_MODEL_TEXT,
                contents: advicePrompt,
                config: { responseMimeType: "application/json", temperature: 0.3 }
            });

            const parsedAdvice = sanitizeAndParseJson<string[]>(adviceResponse.text, "건강 조언");
            if (Array.isArray(parsedAdvice) && parsedAdvice.every(item => typeof item === 'string')) {
                setHealthAdvice(parsedAdvice);
                console.log("건강 조언 (Gemini):", JSON.stringify(parsedAdvice));
            } else {
                console.warn("Received non-array or non-string array for health advice:", parsedAdvice);
                 setHealthAdvice(["AI로부터 받은 조언 형식이 올바르지 않아 표시할 수 없습니다."]);
            }
        } catch (adviceError: any) {
            console.error("Error fetching health advice:", adviceError.message);
            setHealthAdvice(["건강 조언을 가져오는 중 오류가 발생했습니다. 나중에 다시 시도해주세요."]);
        }
      }

      // Exercise Recommendations
      let calorieThresholdForExerciseRecommendation = analysisContext.userTargets.calories / 3; 
      if (analysisContext.mealType === MealType.Snack) {
        calorieThresholdForExerciseRecommendation = 300; 
      }
      
      const potentialExcessCalories = totalNutrients.calories - calorieThresholdForExerciseRecommendation;
      
      let userProfileAndGoalInfo = "사용자의 프로필 및 목표 정보: ";
      if (analysisContext.userProfile) {
          userProfileAndGoalInfo += `${analysisContext.userProfile.gender === Gender.Male ? '남성' : '여성'}, ${analysisContext.userProfile.age}세, 키 ${analysisContext.userProfile.height}cm, 몸무게 ${analysisContext.userProfile.weight}kg.`;
          if (analysisContext.userProfile.targetWeight) {
              userProfileAndGoalInfo += ` 목표 체중은 ${analysisContext.userProfile.targetWeight}kg입니다.`;
          } else {
              userProfileAndGoalInfo += ` 목표 체중은 설정되지 않았습니다.`;
          }
          if (analysisContext.userProfile.aspirations) {
              userProfileAndGoalInfo += ` 주된 건강 목표 및 희망사항은 "${analysisContext.userProfile.aspirations}"입니다.`;
          } else {
              userProfileAndGoalInfo += ` 특별히 설정된 희망사항은 없습니다.`;
          }
      } else {
          userProfileAndGoalInfo = "사용자 프로필 정보가 없습니다."; 
      }


      if (potentialExcessCalories > 100) { 
        const exercisePrompt = `사용자가 ${totalNutrients.calories.toFixed(0)} kcal의 식사를 섭취했습니다. 
${ potentialExcessCalories > 100 ? `이 식사는 칼로리가 다소 높아, 하루 전체 섭취량 관점에서 ${Math.max(150, Math.min(potentialExcessCalories, 300)).toFixed(0)} kcal 정도를 추가로 소모하면 좋습니다.` : '이 식사는 적절한 칼로리 범위 내입니다.'}
${userProfileAndGoalInfo}
사용자의 주된 목표인 '${analysisContext.userProfile?.aspirations || '일반적인 건강 증진'}' 달성과 목표 체중(${analysisContext.userProfile?.targetWeight || '미설정'}kg) 도달에 가장 도움이 되는, 일상 생활에서 짧은 시간(10-30분)안에 쉽게 꾸준히 할 수 있는 운동 한 가지를 한국어로 추천해주세요. 
특히 이 식사로 인해 사용자의 일일 목표 섭취량 중 칼로리(${totalNutrients.calories.toFixed(0)}kcal), 지방(${totalNutrients.fat.toFixed(0)}g) 등이 높아졌다면, 이를 관리하는 데 도움이 될 수 있는 운동(예: 유산소 운동, 가벼운 근력 운동)이면 좋습니다.
추천 운동에 대해 다음 정보를 제공해주세요:
1. 간결하고 설명적인 한국어 이름 (예: "빠르게 걷기", "계단 오르기").
2. 예상 지속 시간 (예: "20분").
3. 해당 시간 동안의 예상 칼로리 소모량 (예: "약 100-150kcal 소모 예상").
응답은 단일 운동 객체를 나타내는 JSON 객체로 반환해주세요. 구조는 다음과 같습니다:
{ "name": "운동 한국어 이름", "duration": "예상 지속 시간", "estimatedCaloriesBurned": "약 XXX kcal 소모 예상" }
예시: { "name": "가벼운 조깅", "duration": "20분", "estimatedCaloriesBurned": "약 150kcal 소모 예상" }
중요: 최종 응답은 반드시 유효한 JSON 객체 형식이어야 하며, JSON.parse()로 오류 없이 파싱 가능해야 합니다. JSON 구조 외의 다른 텍스트, 설명, 주석 등은 절대 포함하지 마세요.`;


        const exerciseResponse = await ai.current.models.generateContent({
            model: GEMINI_MODEL_TEXT,
            contents: exercisePrompt,
            config: { responseMimeType: "application/json", temperature: 0.3 }
        });
        
        try {
            const parsedExercise = sanitizeAndParseJson<ExerciseRecommendation>(exerciseResponse.text, "운동 추천");
             if (parsedExercise && typeof parsedExercise === 'object' && 
                 'name' in parsedExercise && 'duration' in parsedExercise && 'estimatedCaloriesBurned' in parsedExercise &&
                 typeof parsedExercise.name === 'string' && typeof parsedExercise.duration === 'string' && typeof parsedExercise.estimatedCaloriesBurned === 'string') {
                setExerciseRecommendations(parsedExercise);
                console.log("추천 운동 (Gemini):", JSON.stringify(parsedExercise));
            } else {
                setExerciseRecommendations(null); 
                console.warn("Received invalid format for single exercise recommendation:", parsedExercise);
            }
        } catch (e: any) {
            console.error("Failed to parse exercise recommendation JSON:", e.message, "Raw response:", exerciseResponse.text);
            setExerciseRecommendations(null);
        }
      } else {
        setExerciseRecommendations(null); 
      }

    } catch (err: any) {
      console.error("Error during analysis:", err);
      let errorMessage = `분석 중 오류 발생: ${err.message || '알 수 없는 오류'}`;
      if (err.cause && typeof err.cause === 'object') {
        errorMessage += ` 상세정보: ${JSON.stringify(err.cause)}`;
      } else if (err.details) {
         errorMessage += ` 상세정보: ${err.details}`;
      }
      setError(errorMessage);
    } finally {
      setIsLoading(false);
    }
  }, [imageFiles, foodNameHint, ai, userTargets, currentDate, mealTime, mealType, userProfile]);

  const calculateDailyIntake = (date: Date, meals: StoredMealRecord[]): NutrientInfo => {
    const dateString = date.toISOString().slice(0, 10);
    const todaysMeals = meals.filter(meal => meal.date === dateString);
    return todaysMeals.reduce((acc, mealRecord) => ({
      calories: acc.calories + mealRecord.analysis.totalNutrients.calories,
      protein: acc.protein + mealRecord.analysis.totalNutrients.protein,
      carbs: acc.carbs + mealRecord.analysis.totalNutrients.carbs,
      fat: acc.fat + mealRecord.analysis.totalNutrients.fat,
    }), { calories: 0, protein: 0, carbs: 0, fat: 0 });
  };

  const dailyTotalForSummary = calculateDailyIntake(summaryDate, storedMeals);
      
  const handleSummaryDateChange = (newDate: Date) => {
      setSummaryDate(newDate);
  };

  return (
    <div className="min-h-screen flex flex-col items-center">
      <Header />
      <main className="w-full max-w-2xl p-4 md:p-6 bg-white shadow-xl rounded-b-lg mb-8">
        <PhotoUploadForm
          currentDate={currentDate}
          onDateChange={handleDateChange}
          mealTime={mealTime}
          onTimeChange={handleTimeChange}
          mealType={mealType}
          onMealTypeChange={setMealType}
          imageFiles={imageFiles}
          onImageFilesChange={setImageFiles}
          foodNameHint={foodNameHint}
          onFoodNameHintChange={setFoodNameHint}
          onSubmit={analyzeFood}
          isLoading={isLoading}
          userProfile={userProfile}
          onUserProfileChange={handleUserProfileChange}
          userTargets={userTargets}
          targetAdjustmentMessage={targetAdjustmentMessage}
        />

        {isLoading && <Spinner />}
        
        {error && (
          <div className="mt-6 p-4 bg-red-100 text-red-700 border border-red-400 rounded-md">
            <h3 className="font-semibold text-lg">오류 발생</h3>
            <p className="whitespace-pre-wrap break-words">{error}</p>
          </div>
        )}

        {analysisResult && !isLoading && (
          <AnalysisDisplay result={analysisResult} healthAdvice={healthAdvice} />
        )}

        {exerciseRecommendations && !isLoading && (
          <ExerciseRecommender recommendation={exerciseRecommendations} />
        )}
         
        {!isLoading && analysisResult && !exerciseRecommendations && healthAdvice.length > 0 && (
             <div className="mt-6 p-3 bg-sky-50 text-sky-700 border border-sky-200 rounded-md text-sm">
                <p>이 식사에 대한 운동 추천은 생성되지 않았습니다. 위의 식단 조언을 참고하여 건강한 식단을 유지하세요.</p>
            </div>
        )}

        <DailyIntakeSummary
            selectedDate={summaryDate}
            dailyTotals={dailyTotalForSummary}
            userTargets={userTargets}
            onDateChange={handleSummaryDateChange}
            storedMealsForSelectedDate={storedMeals.filter(m => m.date === summaryDate.toISOString().slice(0,10))}
        />
      </main>
    </div>
  );
};

export default App;
